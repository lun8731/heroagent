#!/bin/bash

HERO_GEN1=0
HERO_GEN2=0
PACKAGES="mosquitto mosquitto-clients jq"
BOARDLAYOUT_GEN1="boardlayout_gen1.json"
BOARDLAYOUT_GEN2="boardlayout.json"
AGENTFILE="heroagent_lite"
SERVICEPATH="/etc/systemd/system"
SERVICEFILE=$SERVICEPATH/$AGENTFILE.service

#check root
AMIROOT=`whoami | awk {'print $1'}`
if [ "$AMIROOT" != "root" ] ; then
    echo "ERROR: must run script with sudo"
    exit 1
fi

#check hero sdk version
if [ -f /usr/lib/libHERO.so ]; then
    if [ -f /usr/lib/libHERO.so.1 ]; then
        HERO_GEN1=1
    elif [ -f /usr/lib/libHERO.so.2 ]; then
        HERO_GEN2=1
    else
        echo "Unknown HERO SDK version"
        exit 1
    fi
else
    echo "Please install HERO SDK first"
    exit 1
fi

#check DISTRO
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
fi

#install dependent packages
if [[ ${OS} =~ "Ubuntu" ]] || [[ ${OS} =~ "Debian" ]]; then
    apt update
    apt install -y $PACKAGES
elif [[ ${OS} =~ "Fedora" ]]; then
    dnf check-update
    dnf install -y $PACKAGES
elif [[ ${OS} =~ "Centos" ]]; then
    yum install -y $PACKAGES
fi

#install herosuit
echo "installing herosuit app"
if [ $HERO_GEN1 -eq 1 ]; then
    cp cli_g1/herosuit /usr/bin/
elif [ $HERO_GEN2 -eq 1 ]; then
    cp cli_g2/herosuit /usr/bin/
fi

#install heroagent
echo "installing $AGENTFILE"
cp $AGENTFILE /usr/bin/

#install system service
echo "installing $AGENTFILE service"
if [ -f $SERVICEFILE ]; then
    systemctl stop heroagent_lite.service
    rm $SERVICEFILE
fi

if [ $HERO_GEN1 -eq 1 ]; then
    BOARDLAYOUT=$BOARDLAYOUT_GEN1
elif [ $HERO_GEN2 -eq 1 ]; then
    BOARDLAYOUT=$BOARDLAYOUT_GEN2
fi

$(cat << EOF > $SERVICEFILE
[Unit]
Description=Run agent to report hw monitor

[Service]
Type=simple
Restart=on-failure
RestartSec=30s
User=root
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=$AGENTFILE
Environment="MRAA_JSON_PLATFORM=/etc/$BOARDLAYOUT"
ExecStart=/usr/bin/$AGENTFILE

[Install]
WantedBy=multi-user.target
EOF
)

systemctl daemon-reload
systemctl enable "$AGENTFILE.service"
systemctl start "$AGENTFILE.service"

